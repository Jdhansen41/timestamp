**To delete a parameter**

This example deletes a parameter. There is no output if the command succeeds.

Command::

  aws ssm delete-parameter --name "helloWorld"
